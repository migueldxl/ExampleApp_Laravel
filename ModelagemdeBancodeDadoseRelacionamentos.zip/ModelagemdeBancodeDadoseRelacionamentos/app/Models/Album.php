<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Album extends Model
{
    protected $fillable = ['title', 'release_year', 'artist_id'];

    public function artist(): BelongsTo
    {
        return $this->belongsTo(Artist::class);
    }
}