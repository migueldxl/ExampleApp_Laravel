<?php

namespace App\Http\Controllers;

use App\Models\Album;
use App\Models\Artist; 
use Illuminate\Http\Request;

class AlbumController extends Controller
{
    
    public function create()
    {
        $artists = Artist::all(); 
        return view('albums.create', compact('artists'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'artist_id' => 'required|exists:artists,id',
        ]);

        Album::create($request->all());

        return redirect()->route('albums.create')->with('success', 'Álbum criado com sucesso!');
    }
}